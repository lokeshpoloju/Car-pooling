package com.loyal.carpool.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.loyal.carpool.R;
import com.loyal.carpool.models.DataModel;

import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<DataModel> {

    private static class ViewHolder {
        ImageView ivImage;
        TextView tvContent;
    }

    private Context context;
    private ArrayList<DataModel> data;

    public ListAdapter(Context context, int resourceId, ArrayList<DataModel> items) {

        super(context, resourceId, items);
        this.context = context;
        this.data = items;
    }

    public DataModel getItem(int position) {
        return this.getItem(position);
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View v = convertView;

        final ViewHolder holder;

        if (v == null) {

            LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = vi.inflate(R.layout.list_row, null);

            holder = new ViewHolder();

            holder.ivImage   = v.findViewById(R.id.ivImage);
            holder.tvContent = (TextView) v.findViewById(R.id.tvContent);

            v.setTag(holder);

        }  else {
            holder = (ViewHolder)v.getTag();
        }

        if(data.size() > 0) {
            holder.tvContent.setText(data.get(position).content);
        }

        if (data.get(position).selected){
            holder.ivImage.setImageResource(R.drawable.list_row_selected_img);
        } else {
            holder.ivImage.setImageResource(R.drawable.list_row_img);
        }

        return v;
    }
}
