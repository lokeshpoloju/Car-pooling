package com.loyal.carpool.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.kinvey.android.callback.KinveyReadCallback;
import com.kinvey.android.store.UserStore;
import com.kinvey.java.KinveyException;
import com.kinvey.java.Query;
import com.kinvey.java.core.KinveyClientCallback;
import com.kinvey.java.model.KinveyReadResponse;
import com.loyal.carpool.R;
import com.loyal.carpool.application.CarpoolApp;
import com.loyal.carpool.utils.RideOffer;
import com.loyal.carpool.utils.UserInfo;

public class UpdateProfileActivity extends BaseActivity {

    TextView tv_user_id_value;
    EditText et_password, et_phone_no, et_car_no;
    Button bt_update, bt_cancel;

    UserInfo info = null;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        tv_user_id_value = findViewById(R.id.tv_user_id_value);
        et_password      = findViewById(R.id.et_password);
        et_phone_no      = findViewById(R.id.et_phone_no);
        et_car_no       = findViewById(R.id.et_car_no);

        bt_update        = findViewById(R.id.bt_update);
        bt_cancel        = findViewById(R.id.bt_cancel);

        bt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (info == null) {
                    info = new UserInfo(CarpoolApp.getInstance().getCurrentUser().getId().toString(), et_phone_no.getText().toString(), et_car_no.getText().toString());
                }
                else
                {
                    info.setPhonenumber(et_phone_no.getText().toString());
                    info.setCardnumber(et_car_no.getText().toString());
                }

                try
                {
                    MainActivity.getInstance().getUserDataStore().save(info, new KinveyClientCallback<UserInfo>(){
                        @Override
                        public void onSuccess(UserInfo result) {
                            showToast("Profile updated");
                            finish();
                            MainActivity.getInstance().rideDataStoreSync();
                        }
                        @Override
                        public void onFailure(Throwable error) {
                            showToast("Error occurs...");
                        }
                    });
                }
                catch (KinveyException ke)
                {
                    showToast("Error occurs...");
                }
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tv_user_id_value.setText(CarpoolApp.getInstance().getCurrentUser().getUsername());

        Query query = CarpoolApp.getInstance().getKinveyClient().query().in("userid", new String[]{CarpoolApp.getInstance().getKinveyClient().getActiveUser().getId().toString()});
        MainActivity.getInstance().getUserDataStore().find(query, new KinveyReadCallback<UserInfo>(){
            @Override
            public void onSuccess(KinveyReadResponse kinveyReadResponse) {

                if (kinveyReadResponse.getResult().size() != 0)
                {
                    info = (UserInfo)(kinveyReadResponse.getResult().get(0));
                    updateView(info);
                }
            }
            @Override
            public void onFailure(Throwable error) {
                // Place your code here
            }
        });
    }

    private void updateView(UserInfo info) {
        et_phone_no.setText(info.getPhonenumber());
        et_car_no.setText(info.getCarnumber());
    }
}
