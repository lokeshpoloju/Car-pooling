package com.loyal.carpool.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.kinvey.android.store.DataStore;
import com.kinvey.android.store.UserStore;
import com.kinvey.android.sync.KinveyPushResponse;
import com.kinvey.android.sync.KinveySyncCallback;
import com.kinvey.java.core.KinveyClientCallback;
import com.kinvey.java.model.KinveyPullResponse;
import com.kinvey.java.store.StoreType;
import com.loyal.carpool.R;
import com.loyal.carpool.application.CarpoolApp;
import com.loyal.carpool.utils.RideOffer;
import com.loyal.carpool.utils.UserInfo;

public class MainActivity extends BaseActivity {

    Button bt_search_ride, bt_offer_ride, bt_update_profile, bt_logout;

    private DataStore<RideOffer> rideDataStore;
    private DataStore<UserInfo> userDataStore;

    static MainActivity mApp;
    public static MainActivity getInstance() {

        if (mApp == null) {
            throw new IllegalStateException();
        }

        return mApp;
    }

    public MainActivity() {
        mApp = this;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_search_ride    = findViewById(R.id.bt_search_ride);
        bt_offer_ride     = findViewById(R.id.bt_offer_ride);
        bt_update_profile = findViewById(R.id.bt_update_profile);
        bt_logout         = findViewById(R.id.bt_logout);

        bt_search_ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchRideActivity.class);
                startActivity(intent);
            }
        });

        bt_offer_ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, OfferRideActivity.class);
                startActivity(intent);
            }
        });

        bt_update_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, UpdateProfileActivity.class);
                startActivity(intent);
            }
        });

        bt_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserStore.logout(CarpoolApp.getInstance().getKinveyClient(), new KinveyClientCallback<Void>() {
                    @Override
                    public void onFailure(Throwable throwable) {
                        showLongToast("Please check your network connection");
                    }
                    @Override
                    public void onSuccess(Void aVoid) {
                        Intent intent = new Intent(MainActivity.this, SigninActivity.class);
                        startActivity(intent);
                        finishWithoutAnimation();
                    }
                });
            }
        });


        rideDataStore = DataStore.collection("RideOffer", RideOffer.class, StoreType.SYNC, CarpoolApp.getInstance().getKinveyClient());
        userDataStore = DataStore.collection("UserInfo", UserInfo.class, StoreType.SYNC, CarpoolApp.getInstance().getKinveyClient());
        rideDataStoreSync();
    }

    public DataStore<RideOffer> getRideDataStore() {
        return rideDataStore;
    }
    public DataStore<UserInfo> getUserDataStore() {
        return userDataStore;
    }

    public void rideDataStoreSync() {

        showProgress("Synchronizing now");

        rideDataStore.sync(new KinveySyncCallback() {
            @Override
            public void onSuccess(KinveyPushResponse kinveyPushResponse, KinveyPullResponse kinveyPullResponse) {
                userDataStoreSync();
            }

            @Override
            public void onPullStarted() {

            }

            @Override
            public void onPushStarted() {

            }

            @Override
            public void onPullSuccess(KinveyPullResponse kinveyPullResponse) {

            }


            @Override
            public void onPushSuccess(KinveyPushResponse kinveyPushResponse) {

            }

            @Override
            public void onFailure(Throwable t) {
                 showToast("Faild to fetch ride offer data");
                userDataStoreSync();
            }
        });
    }

    public void userDataStoreSync() {

        userDataStore.sync(new KinveySyncCallback() {
            @Override
            public void onSuccess(KinveyPushResponse kinveyPushResponse, KinveyPullResponse kinveyPullResponse) {
                dismissProgress();
            }

            @Override
            public void onPullStarted() {

            }

            @Override
            public void onPushStarted() {

            }

            @Override
            public void onPullSuccess(KinveyPullResponse kinveyPullResponse) {

            }


            @Override
            public void onPushSuccess(KinveyPushResponse kinveyPushResponse) {

            }

            @Override
            public void onFailure(Throwable t) {
                dismissProgress();
                showToast("Faild to fetch user data");
            }
        });
    }
}
