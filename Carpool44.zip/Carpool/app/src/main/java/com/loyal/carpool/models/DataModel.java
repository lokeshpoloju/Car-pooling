package com.loyal.carpool.models;

public class DataModel {
    public String content;
    public boolean selected;
}
