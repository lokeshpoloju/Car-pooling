package com.loyal.carpool.utils;

import com.google.api.client.json.GenericJson;
import com.google.api.client.util.Key;

public class UserInfo extends GenericJson {

    @Key
    private String userid;

    @Key
    private String phonenumber;

    @Key
    private String carnumber;

    public UserInfo(){}

    public UserInfo(String userid, String phonenumber, String carnumber){
        this.userid = userid;
        this.phonenumber = phonenumber;
        this.carnumber = carnumber;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getCarnumber() {
        return carnumber;
    }

    public void setCardnumber(String carnumber) {
        this.carnumber = carnumber;
    }
}
