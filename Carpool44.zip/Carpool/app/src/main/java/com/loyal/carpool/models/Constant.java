package com.loyal.carpool.models;

public class Constant {

    public static final String SERVER_REMOTE_URL = "http://10.10.10.96/";

    public static final String CHECK_STATE = "check_state";
    public static final String KEY_EAMIL = "key_email";
    public static final String KEY_PASSWORD = "key_password";
}