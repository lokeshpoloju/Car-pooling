package com.loyal.carpool.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.loyal.carpool.R;
import com.loyal.carpool.utils.Utils;

public class BaseActivity extends AppCompatActivity {
    protected static String TAG;
    private ProgressDialog mProgressDlg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

        TAG = getClass().getSimpleName();
    }

    @Override
    public void finish() {
        super.finish();
        //overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
    }

    public void finishWithoutAnimation() {
        super.finish();
    }

    public void finishRightAnimation() {
        super.finish();
        overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
    }

    public void finishLeftAnimation() {
        super.finish();
        overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void showLongToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    protected void showProgress(String title) {
        mProgressDlg = Utils.openNewDialog(this, title, false, false);
    }

    protected void dismissProgress() {
        try {
            if (mProgressDlg != null && mProgressDlg.isShowing())
                mProgressDlg.dismiss();
        } catch (Exception e) {}
    }

    protected boolean hasCamera() {
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) {
            return true;
        } else {
            return false;
        }
    }

    protected boolean isCameraPermissions() {
        return ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    protected boolean isWriteStoragePermissions() {
        return ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }
}
