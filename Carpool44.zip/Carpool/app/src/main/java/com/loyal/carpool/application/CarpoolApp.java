package com.loyal.carpool.application;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;

import com.kinvey.android.Client;
import com.kinvey.android.model.User;
import com.loyal.carpool.models.Constant;

import java.lang.reflect.Method;

public class CarpoolApp extends Application {

    private Client mKinveyClient;
    private User currentUser;

    static SharedPreferences mPreferences;
    static final String CONFIG_NAME = "CarpoolApp";

    static String your_app_key = "kid_Syxlpta5N";
    static String your_app_secret = "7fba35ac3b7e45d1b9c3dfa59d0bdff7";

    static CarpoolApp mApp;
    public static CarpoolApp getInstance() {

        if (mApp == null) {
            throw new IllegalStateException();
        }

        return mApp;
    }

    public CarpoolApp() {
        mApp = this;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Context context = getApplicationContext();
        mPreferences = context.getSharedPreferences(CONFIG_NAME, Context.MODE_PRIVATE);

        mKinveyClient = new Client.Builder(your_app_key, your_app_secret, this).build();

        if(Build.VERSION.SDK_INT >= 24){
            try{
                Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
                m.invoke(null);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public Client getKinveyClient(){
        return mKinveyClient;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    public static String getSetting(String key){
        return mPreferences.getString(key, "");
    }

    public static void saveSetting(String key, String val){
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putString(key, val);
        editor.commit();
    }

    public static void removeUserInfo() {
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.remove(Constant.CHECK_STATE).apply();
        editor.remove(Constant.KEY_EAMIL).apply();
        editor.remove(Constant.KEY_PASSWORD).apply();
    }

    public void setCurrentUser(User user) {
        currentUser = user;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}
