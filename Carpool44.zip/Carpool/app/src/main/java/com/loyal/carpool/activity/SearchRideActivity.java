package com.loyal.carpool.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.kinvey.android.callback.KinveyReadCallback;
import com.kinvey.java.Query;
import com.kinvey.java.model.KinveyReadResponse;
import com.loyal.carpool.R;
import com.loyal.carpool.adapter.ListAdapter;
import com.loyal.carpool.application.CarpoolApp;
import com.loyal.carpool.models.DataModel;
import com.loyal.carpool.utils.RideOffer;
import com.loyal.carpool.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class SearchRideActivity extends BaseActivity {

    EditText et_search;
    Button bt_search, bt_book_ride, bt_cancel, bt_pick_up_location;
    ListView lv_list;

    ArrayList<DataModel> placesList = new ArrayList<>();
    ListAdapter adapter;

    String selectedBookContent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_ride);

        et_search = findViewById(R.id.et_search);
        bt_search = findViewById(R.id.bt_search);
        bt_book_ride = findViewById(R.id.bt_book_ride);
        bt_cancel = findViewById(R.id.bt_cancel);
        bt_pick_up_location = findViewById(R.id.bt_pick_up_location);


        bt_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Utils.isNullOrEmpty(et_search.getText().toString())){
                    showToast("Input Destination Name");
                    return;
                }

                Query query = CarpoolApp.getInstance().getKinveyClient().query().in("destination", new String[]{et_search.getText().toString()});
                MainActivity.getInstance().getRideDataStore().find(query, new KinveyReadCallback<RideOffer>(){
                    @Override
                    public void onSuccess(KinveyReadResponse kinveyReadResponse) {
                        testDataLoad(kinveyReadResponse.getResult());
                    }
                    @Override
                    public void onFailure(Throwable error) {
                        // Place your code here
                    }
                });
            }
        });

        bt_book_ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showToast("Successfully Booked " + selectedBookContent);
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        bt_pick_up_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        lv_list = findViewById(R.id.lv_list);
    }

    public void testDataLoad(List<RideOffer> rides){

        placesList = new ArrayList<>();

        for (int i = 0; i < rides.size(); i ++) {
            RideOffer offer = rides.get(i);
            DataModel m = new DataModel();
            m.content = offer.getCarnumber() + " - " + offer.getPhonenumber() + " - " +
                    offer.getSource() + " - " + offer.getDestination() + " - " + offer.getOfferTime();
            m.selected = false;
            placesList.add(m);
        }

        adapter = new ListAdapter(this, R.layout.list_row, this.placesList);
        this.lv_list.setAdapter(adapter);

        this.lv_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (placesList.get(i).selected){
                    placesList.get(i).selected = false;
                } else {
                    placesList.get(i).selected = true;
                    selectedBookContent = ((DataModel)placesList.get(i)).content;
                }

                adapter.notifyDataSetChanged();
            }
        });
    }
}
