package com.loyal.carpool.utils;

import com.google.api.client.json.GenericJson;
import com.google.api.client.util.Key;

public class RideOffer extends GenericJson {
    @Key
    private String destination;

    @Key
    private String offertime;

    @Key
    private String source;

    @Key
    private String phonenumber;

    @Key
    private String carnumber;

    @Key
    private String price;


    public RideOffer(String s, String toString, String string, String s1, String toString1){}

    public RideOffer(String destination, String offertime, String source, String phonenumber, String carnumber,String price){
        this.destination = destination;
        this.offertime = offertime;
        this.source = source;
        this.phonenumber = phonenumber;
        this.carnumber = carnumber;
        this.price = price;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getOfferTime() {
        return offertime;
    }

    public void setOfferTime(String offertime) {
        this.offertime = offertime;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getCarnumber() {
        return carnumber;
    }

    public void setCarnumber(String carnumber) {
        this.carnumber = carnumber;
    }

    public String getPrice() { return price; }

    public void setPrice(String price){this.price=price;}
}
