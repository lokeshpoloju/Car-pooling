package com.loyal.carpool.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.kinvey.android.callback.KinveyUserCallback;
import com.kinvey.android.model.User;
import com.kinvey.android.store.UserStore;
import com.kinvey.java.core.KinveyClientCallback;
import com.loyal.carpool.R;
import com.loyal.carpool.application.CarpoolApp;
import com.loyal.carpool.utils.Utils;
import java.io.IOException;

public class SigninActivity extends BaseActivity {

    TextView tv_email, tv_password;
    EditText et_email, et_password;
    CheckBox cb_register;
    Button bt_next;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        tv_email = (TextView)findViewById(R.id.tv_email);
        tv_email.setTextColor(getResources().getColor(R.color.colorAccent));

        tv_password = (TextView)findViewById(R.id.tv_password);
        et_email    = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        cb_register = (CheckBox)findViewById(R.id.cb_register);
        bt_next     = (Button)findViewById(R.id.bt_next);


        et_email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                tv_email.setTextColor(getResources().getColor(R.color.colorAccent));
                tv_password.setTextColor(Color.GRAY);
            }
        });

        et_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                tv_email.setTextColor(Color.GRAY);
                tv_password.setTextColor(getResources().getColor(R.color.colorAccent));

                if (!Utils.isValidEmail(et_email.getText().toString())){
                    showToast("This email address is invalid");
                }
            }
        });

        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.isNullOrEmpty(et_email.getText().toString())){
                    showToast("Input Email");
                    return;
                }

                if (!Utils.isValidEmail(et_email.getText().toString())){
                    showToast("This email address is invalid");
                    return;
                }

                if (Utils.isNullOrEmpty(et_password.getText().toString())){
                    showToast("Input Password");
                    return;
                }

                showProgress("Please wait");
                if (cb_register.isChecked()){

                    UserStore.signUp(et_email.getText().toString(), et_password.getText().toString(), CarpoolApp.getInstance().getKinveyClient(), new KinveyClientCallback<User>() {
                        @Override
                        public void onFailure(Throwable t) {
                            showLongToast("Could not sign up.");
                            dismissProgress();
                        }
                        @Override
                        public void onSuccess(User user) {

                            CarpoolApp.getInstance().setCurrentUser(user);

                            showLongToast(user.getUsername() + ", your account has been created.");

                            dismissProgress();

                            Intent intent = new Intent(SigninActivity.this, MainActivity.class);
                            startActivity(intent);
                            finishWithoutAnimation();
                        }
                    });

                } else {

                    try {
                        UserStore.login(et_email.getText().toString(), et_password.getText().toString(), CarpoolApp.getInstance().getKinveyClient(), new KinveyClientCallback<User>() {
                            @Override
                            public void onFailure(Throwable t) {
                                showLongToast("Wrong username or password.");
                                dismissProgress();
                            }
                            @Override
                            public void onSuccess(User user) {

                                CarpoolApp.getInstance().setCurrentUser(user);

                                showLongToast("Welcome back," + user.getUsername() + ".");
                                dismissProgress();

                                Intent intent = new Intent(SigninActivity.this, MainActivity.class);
                                startActivity(intent);
                                finishWithoutAnimation();
                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        showProgress("Please wait");

        UserStore.retrieve(CarpoolApp.getInstance().getKinveyClient(), new KinveyUserCallback<User>() {
            @Override
            public void onFailure(Throwable e) {
                dismissProgress();
            }
            @Override
            public void onSuccess(User user) {

                CarpoolApp.getInstance().setCurrentUser(user);

                showLongToast("Welcome back," + user.getUsername() + ".");
                dismissProgress();

                Intent intent = new Intent(SigninActivity.this, MainActivity.class);
                startActivity(intent);
                finishWithoutAnimation();
            }
        });
    }
}
