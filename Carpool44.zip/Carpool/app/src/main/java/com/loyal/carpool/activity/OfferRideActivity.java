package com.loyal.carpool.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.kinvey.android.store.DataStore;
import com.kinvey.android.sync.KinveyPushResponse;
import com.kinvey.android.sync.KinveySyncCallback;
import com.kinvey.java.KinveyException;
import com.kinvey.java.core.KinveyClientCallback;
import com.kinvey.java.model.KinveyPullResponse;
import com.kinvey.java.store.StoreType;
import com.loyal.carpool.R;
import com.loyal.carpool.application.CarpoolApp;
import com.loyal.carpool.utils.RideOffer;
import com.loyal.carpool.utils.Utils;


public class OfferRideActivity extends BaseActivity {

    EditText et_source, et_destination, et_date_time, et_phone_number, et_car_no;
    Button bt_offer_ride, bt_cancel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_ride);

        et_source = findViewById(R.id.et_source);
        et_destination = findViewById(R.id.et_destination);
        et_date_time = findViewById(R.id.et_date_time);
        et_phone_number = findViewById(R.id.et_phone_number);
        et_car_no = findViewById(R.id.et_car_no);

        bt_offer_ride = findViewById(R.id.bt_offer_ride);
        bt_cancel = findViewById(R.id.bt_cancel);

        bt_offer_ride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Utils.isNullOrEmpty(et_source.getText().toString())){
                    showToast("Input Source");
                    return;
                }

                if (Utils.isNullOrEmpty(et_destination.getText().toString())){
                    showToast("Input Destination");
                    return;
                }

                if (Utils.isNullOrEmpty(et_date_time.getText().toString())){
                    showToast("Input Date and Time");
                    return;
                }

                if (Utils.isNullOrEmpty(et_phone_number.getText().toString())){
                    showToast("Input Phone Number");
                    return;
                }

                if (Utils.isNullOrEmpty(et_car_no.getText().toString())){
                    showToast("Input Car Number");
                    return;
                }

                //String destination, String offertime, String source, String phonenumber, String carnumber

                RideOffer newoffer = new RideOffer(et_destination.getText().toString(), et_date_time.getText().toString(), et_source.getText().toString(),
                        et_phone_number.getText().toString(),et_car_no.getText().toString());

                try
                {
                    MainActivity.getInstance().getRideDataStore().save(newoffer, new KinveyClientCallback<RideOffer>(){
                        @Override
                        public void onSuccess(RideOffer result) {
                            showToast("New Ride Offered...");
                            finish();
                            MainActivity.getInstance().rideDataStoreSync();
                        }
                        @Override
                        public void onFailure(Throwable error) {
                            showToast("Error occurs...");
                        }
                    });
                }
                catch (KinveyException ke)
                {
                    showToast("Error occurs...");
                }
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
